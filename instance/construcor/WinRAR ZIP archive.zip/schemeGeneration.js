function layoutScheme(payload) {
    let layout = []
    let count = payload * 10
    if(payload === 1) {
        for(let i = 0; i < count; i++) {
            layout.push(
            [
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                {
                    title: Math.random(),
                    src: "",
                    rotation: 0,
                    price: 0
                },
                
            ]
            )
        }
    }
    if(payload === 2) {
        for (let i = 0; i < count; i++) {
            layout.push(
                [
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                ]
            )
            
        }
    }
    if (payload === 3) {
        for (let i = 0; i < count; i++) {
            layout.push(
                [
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                ]
            )

        }
    }
    if (payload === 4) {
        for (let i = 0; i < count; i++) {
            layout.push(
                [
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                    {
                        title: Math.random(),
                        src: "",
                        rotation: 0,
                        price: 0
                    },
                ]
            )

        }
    }
    return layout 
}
